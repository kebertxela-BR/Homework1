# Homework1
homework 1 for data599-3

This is a test to confirm our ability to use github and collaborate
